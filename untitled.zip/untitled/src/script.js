// Lista de versículos por temas
const bibleVerses = {
    tristeza: [
        "Salmos 34:18 - O Senhor está perto dos que têm o coração quebrantado e salva os de espírito abatido.",
        "Mateus 5:4 - Bem-aventurados os que choram, pois serão consolados.",
        "Isaías 41:10 - Não temas, pois eu estou contigo; não te assombres, pois eu sou o teu Deus.",
        "Salmos 42:11 - Por que estás abatida, ó minha alma? E por que te perturbas dentro de mim?",
        "Salmos 30:5 - O choro pode durar uma noite, mas a alegria vem pela manhã.",
        "Salmos 73:26 - A minha carne e o meu coração podem fraquejar, mas Deus é a força do meu coração e a minha herança para sempre.",
        "Lamentações 3:22-23 - As misericórdias do Senhor são a causa de não sermos consumidos; suas misericórdias nunca têm fim. Renovam-se cada manhã; grande é a tua fidelidade.",
        "Salmos 147:3 - Ele sara os quebrantados de coração e cura as suas feridas.",
        "Mateus 11:28 - Venham a mim todos os que estão cansados e sobrecarregados, e eu lhes darei descanso.",
        "Salmos 9:9 - O Senhor é um refúgio para os oprimidos, uma torre segura na hora da angústia."
    ],
    alegria: [
        "Filipenses 4:4 - Alegrem-se sempre no Senhor. Novamente direi: Alegrem-se!",
        "Neemias 8:10 - A alegria do Senhor é a sua força.",
        "Salmos 16:11 - Tu me farás conhecer a vereda da vida; na tua presença há plenitude de alegria.",
        "Salmos 126:3 - Grandes coisas fez o Senhor por nós, e por isso estamos alegres.",
        "Romanos 15:13 - Que o Deus da esperança os encha de toda alegria e paz à medida que vocês confiam nele.",
        "Salmos 100:1-2 - Celebrai com júbilo ao Senhor, todas as terras! Servi ao Senhor com alegria; apresentai-vos diante dele com cântico.",
        "Provérbios 17:22 - O coração alegre é bom remédio, mas o espírito abatido seca os ossos.",
        "Salmos 30:11 - Transformaste o meu pranto em dança; despiste as minhas vestes de saco e me cingiste de alegria.",
        "João 15:11 - Tenho-vos dito isto, para que a minha alegria permaneça em vós, e a vossa alegria seja completa.",
        "Salmos 118:24 - Este é o dia que fez o Senhor; alegremo-nos e regozijemo-nos nele."
    ],
    ansiedade: [
        "Filipenses 4:6-7 - Não andem ansiosos por coisa alguma, mas em tudo, pela oração e súplicas, apresentem seus pedidos a Deus. E a paz de Deus guardará seus corações.",
        "1 Pedro 5:7 - Lancem sobre ele toda a sua ansiedade, porque ele tem cuidado de vocês.",
        "Mateus 6:34 - Portanto, não se preocupem com o amanhã, pois o amanhã trará suas próprias preocupações.",
        "Salmos 55:22 - Lança o teu fardo sobre o Senhor, e ele te sustentará; nunca permitirá que o justo seja abalado.",
        "Isaías 26:3 - Tu, Senhor, conservarás em perfeita paz aquele cujo propósito é firme, porque em ti confia.",
        "Salmos 94:19 - Quando a ansiedade já me dominava, o teu consolo trouxe alívio à minha alma.",
        "Mateus 11:28 - Venham a mim todos os que estão cansados e sobrecarregados, e eu lhes darei descanso.",
        "Salmos 37:7 - Descansa no Senhor e espera nele; não te indignes por causa daquele que prospera em seu caminho.",
        "Isaías 41:13 - Pois eu, o Senhor, teu Deus, te tomo pela tua mão direita e te digo: Não temas, eu te ajudo.",
        "Salmos 139:23-24 - Sonda-me, ó Deus, e conhece o meu coração; prova-me e conhece os meus pensamentos."
    ],
    dúvida: [
        "Tiago 1:6 - Peça, porém, com fé, sem duvidar, pois aquele que duvida é como a onda do mar.",
        "Prov ```javascript
        "Provérbios 3:5 - Confie no Senhor de todo o seu coração e não se apoie no seu próprio entendimento.",
        "Salmos 119:105 - A tua palavra é lâmpada para os meus pés e luz para o meu caminho.",
        "Romanos 12:2 - Não se amoldem ao padrão deste mundo, mas transformem-se pela renovação da sua mente.",
        "Hebreus 11:1 - A fé é a certeza daquilo que esperamos e a prova das coisas que não vemos.",
        "Salmos 37:5 - Entrega o teu caminho ao Senhor; confia nele, e ele o fará.",
        "Mateus 21:22 - E tudo o que pedirem em oração, crendo, vocês receberão.",
        "Salmos 10:17 - Senhor, tu ouviste o desejo dos humildes; tu fortalecerás o seu coração e inclinarás os teus ouvidos.",
        "1 João 5:14 - E esta é a confiança que temos para com ele: que, se pedirmos alguma coisa, segundo a sua vontade, ele nos ouve.",
        "Salmos 119:30 - Escolhi o caminho da fidelidade; propus-me seguir as tuas ordenanças."
    ],
    solidão: [
        "Salmos 68:6 - Deus faz que o solitário viva em família; e liberta os cativos para prosperidade.",
        "Deuteronômio 31:6 - Seja forte e corajoso; não tenha medo, nem fique apavorado diante deles, pois o Senhor, o seu Deus, vai com você; ele nunca o deixará, nem o abandonará.",
        "Salmos 25:16 - Volta-te para mim e tem misericórdia de mim, pois estou só e aflito.",
        "Isaías 41:10 - Não temas, pois eu estou contigo; não te assombres, pois eu sou o teu Deus.",
        "Mateus 28:20 - E eis que estou convosco todos os dias, até a consumação do século.",
        "Salmos 139:7 - Para onde me irei do teu espírito? Para onde fugirei da tua presença?",
        "Hebreus 13:5 - Não te deixarei, nem te desampararei.",
        "Salmos 23:4 - Ainda que eu ande pelo vale da sombra da morte, não temerei mal algum, porque tu estás comigo."
    ],
    medo: [
        "Salmos 27:1 - O Senhor é a minha luz e a minha salvação; a quem temerei?",
        "2 Timóteo 1:7 - Pois Deus não nos deu espírito de covardia, mas de poder, de amor e de moderação.",
        "Isaías 43:1 - Não temas, pois eu te remi; chamei-te pelo teu nome; tu és meu.",
        "Salmos 56:3 - Em qualquer tempo que eu temer, confiarei em ti.",
        "Romanos 8:31 - Que diremos, pois, a estas coisas? Se Deus é por nós, quem será contra nós?",
        "Salmos 118:6 - O Senhor está comigo; não temerei; que me poderá fazer o homem?",
        "Isaías 41:13 - Pois eu, o Senhor, teu Deus, te tomo pela tua mão direita e te digo: Não temas, eu te ajudo.",
        "Salmos 34:4 - Busquei ao Senhor, e ele me respondeu; livrou-me de todos os meus temores."
    ],
    gratidão: [
        "1 Tessalonicenses 5:18 - Em tudo dai graças, porque esta é a vontade de Deus em Cristo Jesus para convosco.",
        "Salmos 107:1 - Louvai ao Senhor, porque ele é bom; porque a sua misericórdia dura para sempre.",
        "Colossenses 3:15 - E a paz de Cristo, para a qual também fostes chamados em um só corpo, domine em vossos corações; e sede agradecidos.",
        "Salmos 136:1 - Louvai ao Senhor, porque ele é bom; porque a sua misericórdia dura para sempre.",
        "Filipenses 4:6 - Não andeis ansiosos de coisa alguma; antes, em tudo, sejam conhecidas diante de Deus as vossas petições, pela oração e súplica, com ações de graças.",
        "Salmos 9:1 - Louvarei ao Senhor de todo o meu coração; contarei todas as tuas maravilhas.",
        "Salmos 103:2 - Bendize, ó minha alma, ao Senhor, e não te esqueças de nenhum dos seus benefícios.",
        "Colossenses 4:2 - Perseverai na oração, velando nela com ações de graças."
    ],
    esperança: [
        "Romanos 15:13 - Que o Deus da esperança os encha de toda alegria e paz à medida que vocês confiam nele.",
        "Jeremias 29:11 - Porque sou eu que conheço os planos que tenho para vocês, diz o Senhor; planos de fazê-los prosperar e não de lhes causar dano, planos de dar-lhes esperança e um futuro.",
        "Salmos 39:7 - E agora, Senhor, que espero eu? A minha esperança está em ti.",
        "Hebreus 6:19 - Esta esperança é uma âncora firme e segura para a alma.",
        "Salmos 42:5 - Por que estás abatida, ó minha alma? E por que te perturbas dentro de mim? Espera em Deus, pois ainda o louvarei.",
        "Romanos 8:24 - Pois na esperança fomos salvos. Agora, a esperança que se vê não é esperança. Quem espera pelo que está vendo?",
        "Salmos 71:14 - Mas eu, sempre esperarei; e te louvarei mais e mais.",
        "Miquéias 7:7 - Eu, porém, olharei para o Senhor; esperarei no Deus da minha salvação; o meu Deus me ouvirá."
    ],
    perdão: [
        "Efésios 4:32 - Antes, sede uns para com os outros benignos, misericordiosos, perdoando-vos uns aos outros, como também Deus vos perdoou em Cristo.",
        "Colossenses 3:13 - Suportai-vos e perdoai-vos uns aos outros, se alguém tiver queixa contra outrem; assim como Cristo vos perdoou, assim fazei vós também.",
        "Mateus 6:14 - Pois, se perdoardes aos homens as suas ofensas, também vosso Pai celestial vos perdoará.",
        "Lucas 6:37 - Não julgueis, e não sereis julgados; não condeneis, e não sereis condenados; perdoados, e sereis perdoados.",
        "Salmos 103:12 - Quanto o Oriente está longe do Ocidente, assim afasta de nós as nossas transgressões.",
        "Mateus 18:21-22 - Então, Pedro, aproximando-se dele, perguntou: Senhor, até quantas vezes meu irmão pecará contra mim, e eu lhe perdoarei? Até sete vezes? Respondeu-lhe Jesus: Não te digo que até sete vezes, mas até setenta vezes sete.",
        "Marcos 11:25 - E, quando estiverdes orando, perdoai, se tiverdes alguma coisa contra alguém; para que também vosso Pai, que está nos céus, vos perdoe as vossas ofensas."
    ],
    amor: [
        "1 Coríntios 13:4-7 - O amor é paciente, é benigno; o amor não é invejoso, não se vangloria, não se orgulha. Não se comporta de maneira inconveniente, não busca seus próprios interesses, não se irrita facilmente, não registra o mal.",
        "1 João 4:19 - Nós amamos porque ele nos amou primeiro.",
        "Romanos 13:10 - O amor não faz mal ao próximo. De modo que o amor é o cumprimento da lei.",
        "1 Pedro 4:8 - Acima de tudo, porém, tenham amor intenso uns para com os outros, pois o amor cobre a multidão de pecados.",
        "João 15:12 - O meu mandamento é este: amem-se uns aos outros como eu os amei.",
        "1 João 3:18 - Filhinhos, não amemos de palavra, nem de língua, mas por obras e em verdade.",
        "Romanos 5:8 - Mas Deus prova o seu amor para conosco, em que Cristo morreu por nós, sendo nós ainda pecadores."
    ],
    desilusão: [
        "Salmos 42:11 - Por que estás abatida, ó minha alma? E por que te perturbas dentro de mim? Espera em Deus, pois ainda o louvarei.",
        "Provérbios 13:12 - A esperança que se adia faz adoecer o coração, mas o desejo cumprido é árvore de vida.",
        "Salmos 34:17 - Clamam os justos, e o Senhor os ouve e os livra de todas as suas angústias.",
        "Lamentações 3:20-21 - Lembro-me da minha aflição e do meu pranto, da amargura e do fel. Quero trazer à memória o que me pode dar esperança.",
        "Isaías 40:31 - Mas os que esperam no Senhor renovarão as suas forças; subirão com asas como águias; correrão, e não se cansarão; andarão, e não se fatigarão.",
        "Salmos 43:5 - Por que estás abatida, ó minha alma? E por que te perturbas dentro de mim? Espera em Deus, pois ainda o louvarei, meu Salvador e meu Deus.",
        "Salmos 30:7 - Senhor, pela tua graça, estabeleceste a minha montanha forte; mas, quando escondeste o teu rosto, fiquei perturbado."
    ]
};